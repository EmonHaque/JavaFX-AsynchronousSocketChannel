import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousServerSocketChannel;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.util.concurrent.ArrayBlockingQueue;

public class App extends Application {
    final String HOST = "127.0.0.1";
    final int PORT = 5000;
    AsynchronousServerSocketChannel listener;
    ObservableList<AsynchronousSocketChannel> clients;
    ArrayBlockingQueue<byte[]> messages;
    BooleanProperty isListening;
    ListView<AsynchronousSocketChannel> clientList;
    Thread broadcaster;

    @Override
    public void start(Stage stage) throws Exception {
        isListening = new SimpleBooleanProperty();

        var border = new BorderPane();
        var buttons = new VBox();
        var listen = new Button("Listen");
        var stop = new Button("Stop");
        listen.disableProperty().bind(isListening);
        stop.disableProperty().bind(isListening.not());
        listen.setOnMouseClicked(this::accept);
        stop.setOnMouseClicked(this::stopListening);
        buttons.getChildren().addAll(listen, stop);

        clients = FXCollections.observableArrayList(); //new ArrayBlockingQueue<>(100);
        clientList = new ListView<>();
        clientList.setItems(clients);

        messages = new ArrayBlockingQueue<>(100);

        border.setLeft(buttons);
        border.setCenter(clientList);

        stage.setScene(new Scene(border, 400, 340));
        stage.setTitle("Server");
        stage.show();
    }
    void accept(MouseEvent e)  {
        try {
            listener = AsynchronousServerSocketChannel.open();
            listener.bind(new InetSocketAddress(HOST, PORT));
            isListening.set(true);
            broadcaster = new Thread(this::broadcast);
            broadcaster.start();
        } catch (IOException ex) {
            ex.printStackTrace();
        }

        listener.accept(null, new CompletionHandler<>() {
            @Override
            public void completed(AsynchronousSocketChannel result, Object attachment) {
                listener.accept(null, this);
                Platform.runLater(() -> clients.add(result));
                read(result);
            }

            @Override
            public void failed(Throwable exc, Object attachment) {
                System.out.println("no more connection!");
            }
        });
    }
    void read(AsynchronousSocketChannel channel){
        var buffer = ByteBuffer.allocate(256);
        channel.read(buffer, null, new CompletionHandler<Integer, Object>() {
            @Override
            public void completed(Integer result, Object attachment) {
                var array = new byte[result];
                buffer.get(0, array);
                messages.add(array);
                buffer.clear();
                channel.read(buffer, null, this);
            }

            @Override
            public void failed(Throwable exc, Object attachment) {
                try {
                    channel.close();
                    Platform.runLater(() -> clients.remove(channel));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    void stopListening(MouseEvent e){
        try {
            isListening.set(false);
            listener.close();
            broadcaster.interrupt();
        } catch (IOException ex) {
            ex.printStackTrace();
        }
        for (var client : clients){
            try {
                client.close();
            } catch (IOException ex) {
                //ex.printStackTrace();
            }
        }
    }
    void broadcast(){
        while (!broadcaster.isInterrupted()){
            byte[] message = null;
            try {
                message = messages.take();
                for(var client : clients){
                    client.write(ByteBuffer.wrap(message));
                }
            } catch (InterruptedException e) {
                break;
            }
        }
        System.out.println("broadcast closing ...");
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        isListening.set(false);
        if(listener != null){
            listener.close();
            broadcaster.interrupt();
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
