public class Server {
    public static void main(String[] args) {
        App.main(args);
    }
}
