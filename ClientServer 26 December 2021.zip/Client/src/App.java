import javafx.application.Application;
import javafx.application.Platform;
import javafx.beans.property.BooleanProperty;
import javafx.beans.property.SimpleBooleanProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextArea;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.scene.text.Text;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.AsynchronousSocketChannel;
import java.nio.channels.CompletionHandler;
import java.nio.charset.StandardCharsets;

public class App extends Application {
    final String HOST = "127.0.0.1";
    final int PORT = 5000;
    AsynchronousSocketChannel socket;
    BooleanProperty isConnected;
    TextArea msgBox;
    Button connect, disconnect, send;
    ObservableList<String> messages;
    ListView<String> messagesView;
    Text status;

    @Override
    public void start(Stage stage) throws Exception {
        isConnected = new SimpleBooleanProperty();
        var leftPane = new VBox();
        connect = new Button("Connect");
        disconnect = new Button("Disconnect");
        connect.disableProperty().bind(isConnected);
        disconnect.disableProperty().bind(isConnected.not());
        connect.setOnMouseClicked(this::connect);
        disconnect.setOnMouseClicked(this::disconnect);
        leftPane.getChildren().addAll(connect, disconnect);

        var bottomPane = new VBox();
        msgBox = new TextArea();
        status = new Text();
        send = new Button("Send");
        send.setOnMouseClicked(this::send);
        bottomPane.getChildren().addAll(msgBox, send, status);
        bottomPane.setMaxHeight(100);

        messages = FXCollections.observableArrayList();
        messagesView = new ListView<>(messages);

        var border = new BorderPane();
        border.setLeft(leftPane);
        border.setCenter(messagesView);
        border.setBottom(bottomPane);


        stage.setScene(new Scene(border, 400,340));
        stage.setTitle("Client");
        stage.show();
    }

    void connect(MouseEvent e){
        try {
            status.setText("trying to connect ...");
            socket = AsynchronousSocketChannel.open();
            socket.connect(new InetSocketAddress(HOST, PORT), null, new CompletionHandler<Void, Object>() {
                @Override
                public void completed(Void result, Object attachment) {
                    isConnected.set(true);
                    read();
                    Platform.runLater(() -> status.setText("connected"));
                }

                @Override
                public void failed(Throwable exc, Object attachment) {
                    isConnected.set(false);
                    Platform.runLater(() -> status.setText("failed to connect"));
                }
            });
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
    void read(){
        var buffer = ByteBuffer.allocate(256);
        socket.read(buffer, null, new CompletionHandler<Integer, Object>() {
            @Override
            public void completed(Integer result, Object attachment) {
                var array = new byte[result];
                buffer.get(0, array);
                Platform.runLater(() -> messages.add(new String(array)));
                buffer.clear();
                socket.read(buffer, null, this);
            }

            @Override
            public void failed(Throwable exc, Object attachment) {
                try {
                    socket.close();
                    isConnected.set(false);
                    Platform.runLater(() -> status.setText("disconnected"));
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        });
    }
    void send(MouseEvent e){
        var array = msgBox.getText().getBytes(StandardCharsets.UTF_8);
        socket.write(ByteBuffer.wrap(array));
        msgBox.setText("");
    }
    void disconnect(MouseEvent e){
        if(socket != null){
            try {
                socket.close();
                isConnected.set(false);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    public static void main(String[] args) {
        launch(args);
    }
}
